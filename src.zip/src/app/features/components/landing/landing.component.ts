import { AfterViewInit, Component,  ElementRef } from '@angular/core';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { NavbarComponent } from '../../../shared/components/navbar/navbar.component';
import { CartComponent } from '../cart/cart.component';

gsap.registerPlugin(ScrollTrigger);

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [NavbarComponent, CartComponent],
  templateUrl: './landing.component.html',
  styleUrl: './landing.component.scss'
})
export class LandingComponent implements AfterViewInit {
  
  tl = gsap.timeline();
  productList = [{
    id: 1,
    prod_name: 'iphone 17 Pro',
  },{
    id: 1,
    prod_name: 'iphone 17 ',
  },{
    id: 1,
    prod_name: 'iphone 16 Pro Max',
  },{
    id: 1,
    prod_name: 'iphone 16 Pro',
  },{
    id: 1,
    prod_name: 'iphone 16 ',
  },{
    id: 1,
    prod_name: 'iphone 15 Pro Max',
  },{
    id: 1,
    prod_name: 'iphone 15 Pro',
  },{
    id: 1,
    prod_name: 'iphone 15',
  },
]
  constructor(private el: ElementRef){}

  ngAfterViewInit(): void {
    this.tl.from(this.el.nativeElement.quesrySelector('#h1a'),{
      y: -100,
      opacity:1,
      duration: 0.3,
      delay: 0.3,
      ScrollTrigger:{
        trigger:this.el.nativeElement.querySelector('.sec_1'),
        scroller: 'body',
        start: 'top center',
        end: 'bootom top',
        markers: true,
      }
    });
  }
}
